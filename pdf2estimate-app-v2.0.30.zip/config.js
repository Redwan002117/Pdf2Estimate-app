window.env = {
    VITE_GEMINI_API_KEY: ""
};
